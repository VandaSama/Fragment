package com.vanda.fragmentkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.vanda.fragmentkotlin.fragment.FragmentSatu

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val FragmentSatu = FragmentSatu()
        val FragmentDua = FragmentDua()

        supportFragmentManager.beginTransaction().apply {
            replace(R.id.f1Fragment, FragmentSatu)
            commit()
        }

        val btnFragmentSatu = findViewById<Button>(R.id.btnFirstFragment)

        btnFragmentSatu.setOnClickListener{
            supportFragmentManager.beginTransaction().apply {
            replace(R.id.f1Fragment, FragmentSatu)
            commit()
            }
        }

        val btnFragmentDua = findViewById<Button>(R.id.btnSecondFragment)

        btnFragmentDua.setOnClickListener{
            supportFragmentManager.beginTransaction().apply {
            replace(R.id.f1Fragment, FragmentDua)
            commit()

            }
        }
    }
}